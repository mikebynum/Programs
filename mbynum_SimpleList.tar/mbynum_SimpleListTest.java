// Name         : Mike Bynum
// Class        : CSCI 1620-301
// Program #    : 1
// Due Date     : 1 July 2010
//
// Honor Pledege:   On my honor as a student of the University of Nebraska at
//                  Omaha, I have neither given nor received unauthorized help
//                  on this homework assignment.
//
// NAME:    Mike Bynum
// NUID:    343
// EMAIL:   mbynum@unomaha.edu
//
// Partners:    NONE
//
// Description:

public class mbynum_SimpleListTest
{

    public static void main(String[] args)
    {
        mbynum_SimpleList test=new mbynum_SimpleList();
        test.getData();
        test.processData();
        test.displayData();
        test.clearData();
    }

}
